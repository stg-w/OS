# ==========================================
# LivingMemoryOS MIMIC-IV Dashboard
# ==========================================

import os
import pandas as pd
import plotly.express as px
import streamlit as st

# ==========================================
# PAGE CONFIG
# ==========================================

st.set_page_config(
    page_title="LivingMemoryOS",
    page_icon="🧠",
    layout="wide"
)

# ==========================================
# CSS
# ==========================================

def load_css():

    st.markdown("""
    <style>

    .stApp{
        background-color:#f6f8fc;
    }

    section[data-testid="stSidebar"]{
        background:#eef4fb;
    }

    h1,h2,h3,h4{
        color:#1f2937;
        font-weight:700;
    }

    .hero-card{
        background:white;
        padding:40px;
        border-radius:24px;
        text-align:center;
        margin-bottom:20px;
        box-shadow:0 4px 20px rgba(0,0,0,.06);
    }

    div[data-testid="metric-container"]{
        background:white;
        border-radius:18px;
        padding:15px;
        border:1px solid #edf2f7;
        box-shadow:0 4px 12px rgba(0,0,0,.05);
    }

    .patient-card{
        background:white;
        padding:18px;
        border-radius:16px;
        margin-bottom:12px;
        border-left:6px solid #1f6feb;
        box-shadow:0 2px 10px rgba(0,0,0,.05);
    }

    </style>
    """,
    unsafe_allow_html=True)

# ==========================================
# DATA LOADER
# ==========================================

@st.cache_data
def load_data():

    candidates = [

        "data/livingmemory_results_v4.csv",

        "livingmemory_results_v4.csv",

        "data/livingmemory_results_new.csv",

        "livingmemory_results_new.csv"

    ]

    for path in candidates:

        if os.path.exists(path):

            return pd.read_csv(path)

    return None

# ==========================================
# SIDEBAR
# ==========================================

def render_sidebar(df):

    st.sidebar.markdown("# ⚙️ System Controls")

    cms_threshold = st.sidebar.slider(
        "CMS Threshold",
        0.0,
        1.0,
        0.50,
        0.05,
        key="mimic_cms_slider"
    )

    memory_slots = st.sidebar.slider(
        "Memory Capacity",
        50,
        500,
        100,
        10,
        key="mimic_memory_slider"
    )

    st.sidebar.markdown("---")

    st.sidebar.metric(
        "Patients",
        len(df)
    )

    st.sidebar.metric(
        "Average CMS",
        round(df["cms"].mean(),3)
    )

    return cms_threshold, memory_slots

# ==========================================
# HERO
# ==========================================

def render_hero():

    st.markdown("""
    <div class="hero-card">

    <h1 style="font-size:3rem;">
        🧠 LivingMemoryOS
    </h1>

    <h3 style="color:#1f6feb;">
        Self-Evolving Clinical Memory Architecture
    </h3>

    <p style="font-size:18px;color:#6b7280;">

    Prognostic Retention • Patient Criticality Inheritance
    • AI Mortality Prediction • Dynamic Memory Evolution

    </p>

    </div>
    """,
    unsafe_allow_html=True)

# ==========================================
# KPI CARDS
# ==========================================

def render_metrics(df):

    total_patients = len(df)

    critical_patients = len(
        df[df["cms"] > 0.70]
    )

    avg_cms = round(
        df["cms"].mean(),
        3
    )

    max_cms = round(
        df["cms"].max(),
        3
    )

    c1,c2,c3,c4 = st.columns(4)

    c1.metric(
        "Patients",
        total_patients
    )

    c2.metric(
        "Critical Patients",
        critical_patients
    )

    c3.metric(
        "Average CMS",
        avg_cms
    )

    c4.metric(
        "Highest CMS",
        max_cms
    )

# ==========================================
# CMS DISTRIBUTION
# ==========================================

def render_cms_distribution(df):

    st.subheader("Clinical Memory Score Distribution")

    fig = px.histogram(
        df,
        x="cms",
        nbins=25,
        color_discrete_sequence=["#1f6feb"]
    )

    fig.update_layout(
        template="plotly_white",
        height=450
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )

# ==========================================
# AI ANALYSIS
# ==========================================

def render_ai_analysis(df):

    if "ai_risk" not in df.columns:

        st.info(
            "ai_risk column not found."
        )
        return

    st.subheader(
        "AI Mortality Risk vs CMS"
    )

    fig = px.scatter(
        df,
        x="ai_risk",
        y="cms",
        color="cms",
        size="cms",
        hover_data=[
            "subject_id",
            "hadm_id"
        ]
    )

    fig.update_layout(
        template="plotly_white",
        height=450
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )

# ==========================================
# CARE UNIT ANALYSIS
# ==========================================

def render_care_distribution(df):

    if "first_careunit" not in df.columns:
        return

    st.subheader(
        "Care Unit Distribution"
    )

    counts = (
        df["first_careunit"]
        .astype(str)
        .value_counts()
        .reset_index()
    )

    counts.columns = [
        "Care Unit",
        "Patients"
    ]

    fig = px.bar(
        counts,
        x="Care Unit",
        y="Patients",
        color="Patients",
        color_continuous_scale="Blues"
    )

    fig.update_layout(
        template="plotly_white",
        height=450
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )

# ==========================================
# HEATMAP
# ==========================================

def render_risk_heatmap(df):

    if "ai_risk" not in df.columns:
        return

    st.subheader(
        "CMS-Risk Density Heatmap"
    )

    fig = px.density_heatmap(
        df,
        x="cms",
        y="ai_risk",
        nbinsx=20,
        nbinsy=20,
        color_continuous_scale="Blues"
    )

    fig.update_layout(
        template="plotly_white",
        height=450
    )

    st.plotly_chart(
        fig,
        use_container_width=True
    )

# ==========================================
# TOP PATIENTS
# ==========================================

def render_top_patients(df):

    st.subheader(
        "🚨 Highest Priority Patients"
    )

    top = (
        df.sort_values(
            "cms",
            ascending=False
        )
        .head(20)
    )

    st.dataframe(
        top,
        use_container_width=True
    )

# ==========================================
# MAIN DASHBOARD
# ==========================================

def render_dashboard():

    load_css()

    results = load_data()

    if results is None:

        st.error(
            "livingmemory_results_v4.csv not found."
        )

        return

    cms_threshold, memory_slots = render_sidebar(results)

    filtered = results[
        results["cms"] >= cms_threshold
    ]

    render_hero()

    render_metrics(filtered)

    st.divider()

    col1,col2 = st.columns(2)

    with col1:
        render_cms_distribution(filtered)

    with col2:
        render_ai_analysis(filtered)

    st.divider()

    col3,col4 = st.columns(2)

    with col3:
        render_care_distribution(filtered)

    with col4:
        render_risk_heatmap(filtered)

    st.divider()

    render_top_patients(filtered)

# ==========================================
# ENTRY POINT
# ==========================================

if __name__ == "__main__":
    render_dashboard()